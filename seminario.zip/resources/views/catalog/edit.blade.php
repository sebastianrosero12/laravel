@extends('layouts.master')
 
@section('content')
     Edit
@stop