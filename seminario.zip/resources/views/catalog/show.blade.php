@extends('layouts.master')
 
@section('content')
     show
@stop