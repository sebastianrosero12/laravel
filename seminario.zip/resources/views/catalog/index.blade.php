@extends('layouts.master')
 
@section('content')
     Index
@stop